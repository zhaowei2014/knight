package com.zw.knight.config.namespace;

/**
 * TODO:DOCUMENT ME!
 *
 * @author zw
 * @date 2020/7/10
 */
public interface Balanceable {
    int getWeight();
}
